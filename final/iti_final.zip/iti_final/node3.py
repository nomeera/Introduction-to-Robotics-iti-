#!/usr/bin/env python3

import rclpy           
from rclpy.node import Node
from std_msgs.msg import String, Int16


class my_node(Node):     
    def __init__(self):
        super().__init__("number")
        print("Node Started")
        self.create_subscription(String,"number",self.number_call,10)
        self.pub=self.create_publisher(Int16,"accumulated_number",10)
        self.accumulator=0
        
    
    def number_call(self,msg):
        x=msg.data
        lst=x.split(",")
        self.number=int(lst[1])
        accumulated_type=lst[0]
        if accumulated_type=="Add":
            self.accumulator = self.accumulator + self.number 
        elif accumulated_type=="Subtract":
            self.accumulator = self.accumulator - self.number 

        accumulated_num=Int16()
        accumulated_num.data=self.accumulator
        self.pub.publish(accumulated_num)

        
def main(args=None):
    rclpy.init(args=args)
    node=my_node()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__=="__main__":
    main()
